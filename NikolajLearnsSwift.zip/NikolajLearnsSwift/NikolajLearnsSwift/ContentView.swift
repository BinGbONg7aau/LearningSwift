//
//  ContentView.swift
//  NikolajLearnsSwift
//
//  Created by Nikolaj van Gool on 02/07/2026.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Text("Hello, world!")
            Text("Tihi")
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
